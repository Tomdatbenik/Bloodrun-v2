﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TrapType
{
    SpikeTrap = 1,
    Darter = 2,
    AlwaysActiveTrap = 3,
    RotatingDarter = 4,
    RotateTrap = 5
}
