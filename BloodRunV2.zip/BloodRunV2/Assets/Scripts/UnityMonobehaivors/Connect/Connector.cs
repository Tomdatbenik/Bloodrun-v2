﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Connector : ScriptableObject
{
    public UDPClient uClient;
    public TCPClient tClient;

}
