﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneLogic 
{
    public void loadGame()
    {

    }
}
